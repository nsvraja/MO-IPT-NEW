The folder contains the SrVO_3 data of doped three-orbital Hubbard model for
density-density type interactions.

##################
parameter details:
##################

Case: Degenerate(\epsilon_1 = \epsilon_2 = \epsilon_3 = 0.0)

Total filling: n_tot=1.0766

Hubbard interaction parameter U/t = 1.2

Hund's coupling J/t = 0.10

Temperature T/t = 0.1
