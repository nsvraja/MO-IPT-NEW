The folder contains the data of doped two-orbital Hubbard model for
density-density type interactions.

##################
parameter details:
##################

Case: Degenerate(\epsilon_1 = \epsilon_2 = 0.0)

Total filling: n_tot=1.6

Hubbard interaction parameter U/t = 1.5 

Hund's coupling J/t = 0.0

Temperature T/t = 0.0
