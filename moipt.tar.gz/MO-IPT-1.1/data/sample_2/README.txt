The folder contains the data of Half-filled two-orbital Hubbard model for
density-density type interactions.

##################
parameter details:
##################

Case: Non-Degenerate(\epsilon_1/t = 0.0 and \epsilon_2/t = -0.20 )

Total filling: n_tot = 2.0

Hubbard interaction parameter U/t = 1.5 

Hund's coupling J/t = 0.0

Temperature T/t = 0.0
